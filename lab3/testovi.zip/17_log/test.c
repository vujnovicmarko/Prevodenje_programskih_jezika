int main(void) {
    int y = 12;
    int x = !1 && y || x + 2 == 2 < 3 >= 5;
    return main==1;
}
