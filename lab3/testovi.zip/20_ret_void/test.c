int main(void) {
    return 1;
    return 'a';
    return 3 + 5;
    return;
}
