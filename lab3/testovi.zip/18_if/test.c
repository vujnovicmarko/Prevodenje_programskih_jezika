int main(void) {
    if (1) {
        return 1;
    } else if (main) {
        return 2;
    }
}
