int main(void) {
    return 3;
}
int main(void) {
    return 3;
}
