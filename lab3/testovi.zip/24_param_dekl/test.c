int x(void) {
    return 0;
}
int f(int x) {
    return x;
}
int g(int x) {
    int x = 3;
    return x;
}
