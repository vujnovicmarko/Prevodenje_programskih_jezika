int main(void) {
    const int x = 3;
    const int y;
    return 0;
}
