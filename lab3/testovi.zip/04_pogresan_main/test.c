char main(void) {
    return 'a';
}
