int main(void) {
    int f(void);
    return f();
}
