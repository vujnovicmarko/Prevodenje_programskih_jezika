int main(void) {
    char a[5] = "123";
    const char b[5] = { 'a', 'b', 'c' };
    char c[1025];
    return 0;
}
