int main(void) {
    int x, y;
    x = y = 3;
    ++x;
    x = --y;
    y-- = x++;
    return 0;
}
